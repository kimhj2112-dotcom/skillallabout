(() => {
  "use strict";
  const DATA = window.SKILL_DATA || { areas: [], skills: [] };
  const RECIPES = window.RECIPES || [];
  const AREA = Object.fromEntries(DATA.areas.map(a => [a.id, a]));
  const BY_ID = Object.fromEntries(DATA.skills.map(s => [s.id, s]));
  const SOURCES = ["전체", "공식", "Anthropic", "커뮤니티", "내 스킬", "모음집"];
  const $ = s => document.querySelector(s);
  const esc = s => String(s ?? "").replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));

  // 즐겨찾기 — 브라우저마다 따로 저장, 안 되면 메모리에만
  let favs = new Set();
  try { favs = new Set(JSON.parse(localStorage.getItem("sab-favs") || "[]")); } catch (e) {}
  const saveFavs = () => { try { localStorage.setItem("sab-favs", JSON.stringify([...favs])); } catch (e) {} };

  const state = { q: "", area: null, source: "전체", installed: false, fav: false };

  // 검색어 별칭: 사람이 쓰는 말 → 분야
  const ALIAS = {
    쇼츠: "video", 영상: "video", 유튜브: "video", 동영상: "video", 음성: "video", 더빙: "video",
    대본: "script", 스크립트: "script", 기획: "script", 팟캐스트: "script",
    글: "writing", 작문: "writing", 블로그: "writing", 자소서: "writing", 이력서: "writing",
    조사: "research", 자료: "research", 논문: "research", 리서치: "research",
    광고: "marketing", 마케팅: "marketing", 홍보: "marketing", 썸네일: "marketing", sns: "marketing",
    코딩: "code", 개발: "code", 코드: "code", 테스트: "code", 버그: "code",
    엑셀: "docs", 워드: "docs", ppt: "docs", 발표: "docs", 한글: "docs", hwp: "docs",
    디자인: "design", 포스터: "design", 이미지: "design",
    데이터: "data", 차트: "data", 분석: "data", 공부: "learn", 시험: "learn",
    보안: "security", 자동화: "automation", 스킬만들기: "meta", 플러그인: "meta"
  };

  const srcClass = s => (s.source === "공식" || s.source === "Anthropic") ? "src-official" : s.source === "내 스킬" ? "src-mine" : "";

  function matches(s) {
    if (state.area && !s.areas.includes(state.area)) return false;
    if (state.source !== "전체" && s.source !== state.source) return false;
    if (state.installed && !s.installed) return false;
    if (state.fav && !favs.has(s.id)) return false;
    if (!state.q) return true;
    const terms = state.q.toLowerCase().split(/\s+/).filter(Boolean);
    const hay = [s.name, s.author, s.purpose, s.example, s.group, ...s.areas.map(a => AREA[a]?.name)].join(" ").toLowerCase();
    return terms.every(t => hay.includes(t) || (ALIAS[t] && s.areas.includes(ALIAS[t])));
  }

  function renderAreas() {
    const counts = {};
    DATA.skills.forEach(s => s.areas.forEach(a => counts[a] = (counts[a] || 0) + 1));
    $("#areas").innerHTML =
      `<button class="area ${state.area ? "" : "is-on"}" data-area="">전체 <span class="n">${DATA.skills.length}</span></button>` +
      DATA.areas.map(a => `<button class="area ${state.area === a.id ? "is-on" : ""}" data-area="${a.id}">${a.icon} ${esc(a.name)} <span class="n">${counts[a.id] || 0}</span></button>`).join("");
  }

  function renderSources() {
    $("#sources").innerHTML = SOURCES.map(s => `<button class="${state.source === s ? "is-on" : ""}" data-src="${esc(s)}">${esc(s)}</button>`).join("");
  }

  function card(s) {
    return `<article class="card" data-id="${s.id}">
      <button class="fav ${favs.has(s.id) ? "is-on" : ""}" data-fav="${s.id}" aria-label="즐겨찾기">${favs.has(s.id) ? "★" : "☆"}</button>
      <div class="card-top">
        <span class="badge ${srcClass(s)}">${esc(s.source)}</span>
        ${s.installed ? `<span class="badge inst">✓ 설치됨</span>` : ""}
        ${s.origin === "gemini" ? `<span class="badge gem">제미나이 수집</span>` : ""}
      </div>
      <h3>${esc(s.name)}</h3>
      <div class="by">${esc(s.author)}</div>
      <p>${esc(s.purpose)}</p>
      <div class="tags">${s.areas.map(a => `<span>#${esc(AREA[a]?.name || a)}</span>`).join("")}</div>
      <div class="row">
        <button class="btn primary" data-open="${s.id}">사용법·설치</button>
        <button class="btn" data-copy="${esc(s.example)}">예시 복사</button>
      </div>
    </article>`;
  }

  function renderGrid() {
    const list = DATA.skills.filter(matches);
    // 설치된 것 → 공식 → 나머지 순
    const rank = s => (s.installed ? 0 : 2) + (srcClass(s) === "src-official" ? 0 : 1);
    list.sort((a, b) => rank(a) - rank(b) || a.name.localeCompare(b.name));
    $("#grid").innerHTML = list.map(card).join("");
    $("#empty").hidden = list.length > 0;
    $("#count").textContent = `${list.length}개 표시`;
  }

  function recipesUsing(id) { return RECIPES.filter(r => r.steps.some(st => st.skill === id)); }

  function openDetail(id, push = true) {
    const s = BY_ID[id];
    if (!s) return;
    const ins = s.install || { steps: [], commands: [] };
    const used = recipesUsing(id);
    $("#detail").innerHTML = `
      <div class="d-head">
        <div class="card-top">
          <span class="badge ${srcClass(s)}">${esc(s.source)}</span>
          ${s.installed ? `<span class="badge inst">✓ 내 계정에 설치됨</span>` : ""}
          <span class="badge">${esc(ins.label || "")}</span>
        </div>
        <h2 id="d-name">${esc(s.name)}</h2>
        <div class="by">만든 이 · ${esc(s.author)}${s.group ? " · " + esc(s.group) : ""}</div>
      </div>
      <div class="d-sec"><h4>용도</h4><p>${esc(s.purpose)}</p></div>
      <div class="d-sec"><h4>분야</h4><div class="chips">${s.areas.map(a => `<span>${AREA[a]?.icon || ""} ${esc(AREA[a]?.name || a)}</span>`).join("")}</div></div>
      <div class="d-sec"><h4>사용 방법 — 이렇게 말해 보세요</h4>
        <div class="say-box"><q>${esc(s.example)}</q>
          <button class="btn" data-copy="${esc(s.example)}">문장 복사</button>
          <button class="btn" data-copy="${esc(s.name + " 스킬을 써서 " + s.example)}">스킬 이름 넣어 복사</button>
        </div>
        <p class="hint">스킬은 켜져 있으면 Claude가 알아서 고릅니다. 확실히 쓰게 하려면 문장에 스킬 이름을 넣으세요.</p>
      </div>
      <div class="d-sec"><h4>설치 방법</h4>
        <ol class="steps">${(ins.steps || []).map(t => `<li>${esc(t)}</li>`).join("")}</ol>
        ${(ins.commands || []).map(c => `<div class="cmd"><code>${esc(c)}</code><button class="copy" data-copy="${esc(c)}">복사</button></div>`).join("")}
      </div>
      ${used.length ? `<div class="d-sec in-recipes"><h4>이 스킬이 들어간 레시피</h4>${used.map(r => `<button data-recipe="${r.id}">${r.icon} ${esc(r.title)}</button>`).join("")}</div>` : ""}
      ${s.note ? `<div class="d-sec"><h4>메모</h4><p>${esc(s.note)}</p></div>` : ""}
      <div class="d-links">
        ${s.url ? `<a class="btn primary" href="${esc(s.url)}" target="_blank" rel="noopener">GitHub에서 보기 ↗</a>` : ""}
        <button class="btn" data-fav="${s.id}">${favs.has(s.id) ? "★ 즐겨찾기 해제" : "☆ 즐겨찾기"}</button>
        <button class="btn" data-copy="${esc(location.href.split("#")[0] + "#skill=" + s.id)}">링크 복사</button>
      </div>`;
    $("#sheet").hidden = false;
    document.body.style.overflow = "hidden";
    if (push) history.replaceState(null, "", "#skill=" + s.id);
  }

  function closeDetail() {
    $("#sheet").hidden = true;
    document.body.style.overflow = "";
    if (location.hash.startsWith("#skill=")) history.replaceState(null, "", location.pathname + location.search);
  }

  function renderRecipes() {
    $("#recipes").innerHTML = RECIPES.map(r => `
      <article class="recipe" id="recipe-${r.id}">
        <h3>${r.icon} ${esc(r.title)}</h3>
        <div class="d">${esc(r.desc)}</div>
        <ol>${r.steps.map(st => {
          const s = BY_ID[st.skill];
          return `<li><button data-open="${st.skill}">${esc(s ? s.name : st.skill)}</button>${s && s.installed ? `<span class="inst-mark">✓ 설치됨</span>` : ""}<span class="say">${esc(st.say)}</span></li>`;
        }).join("")}</ol>
      </article>`).join("");
  }

  function setView(v) {
    document.querySelectorAll(".tab").forEach(t => t.classList.toggle("is-on", t.dataset.view === v));
    document.querySelectorAll(".view").forEach(el => el.classList.toggle("is-on", el.id === "view-" + v));
    window.scrollTo({ top: 0 });
  }

  let toastT;
  function toast(msg) {
    const t = $("#toast"); t.textContent = msg; t.classList.add("show");
    clearTimeout(toastT); toastT = setTimeout(() => t.classList.remove("show"), 1600);
  }
  async function copy(text) {
    try { await navigator.clipboard.writeText(text); }
    catch (e) {
      const ta = document.createElement("textarea"); ta.value = text; document.body.appendChild(ta);
      ta.select(); try { document.execCommand("copy"); } catch (_) {} ta.remove();
    }
    toast("복사했어요");
  }

  // 이벤트 (위임)
  document.addEventListener("click", e => {
    const el = e.target.closest("[data-copy],[data-open],[data-fav],[data-area],[data-src],[data-view],[data-close],[data-recipe]");
    if (!el) {
      const c = e.target.closest(".card"); if (c) openDetail(c.dataset.id); return;
    }
    if (el.dataset.copy !== undefined) { e.stopPropagation(); copy(el.dataset.copy); return; }
    if (el.dataset.fav) {
      e.stopPropagation();
      const id = el.dataset.fav; favs.has(id) ? favs.delete(id) : favs.add(id); saveFavs();
      renderGrid(); if (!$("#sheet").hidden) openDetail(id, false); return;
    }
    if (el.dataset.open) { openDetail(el.dataset.open); return; }
    if (el.dataset.area !== undefined) { state.area = el.dataset.area || null; renderAreas(); renderGrid(); return; }
    if (el.dataset.src) { state.source = el.dataset.src; renderSources(); renderGrid(); return; }
    if (el.dataset.view) { setView(el.dataset.view); return; }
    if (el.dataset.recipe) { closeDetail(); setView("recipes"); setTimeout(() => document.getElementById("recipe-" + el.dataset.recipe)?.scrollIntoView({ behavior: "smooth", block: "start" }), 30); return; }
    if (el.dataset.close !== undefined) closeDetail();
  });
  $("#q").addEventListener("input", e => { state.q = e.target.value.trim(); renderGrid(); });
  $("#only-installed").addEventListener("change", e => { state.installed = e.target.checked; renderGrid(); });
  $("#only-fav").addEventListener("change", e => { state.fav = e.target.checked; renderGrid(); });
  document.addEventListener("keydown", e => {
    if (e.key === "Escape" && !$("#sheet").hidden) closeDetail();
    if (e.key === "/" && document.activeElement !== $("#q")) { e.preventDefault(); setView("browse"); $("#q").focus(); }
  });

  $("#stat-total").textContent = DATA.skills.length;
  renderAreas(); renderSources(); renderGrid(); renderRecipes();
  const m = location.hash.match(/^#skill=(.+)$/);
  if (m) openDetail(decodeURIComponent(m[1]), false);
})();
